lena = imread('lenaTest2.jpg');  %adquire imagem Lena como matriz
tam = size(lena); %obter tamanho da matriz da imagem
lena_v = double(reshape(lena,tam(1)*tam(2),1)); %reordena a matriz como um vetor
lena_b = de2bi(lena_v,8)'; %converte de decimal para bin�rio
tam_b = size(lena_b); %obtem tamanho da nova matriz com dados em bin�rio
lena_b = reshape(lena_b,[tam_b(1)*tam_b(2) 1]); %ajusta os bits para ficarem todos em uma coluna
tam_b = size(lena_b); %adquire as novas dimens�es do vetor bin�rio
pe = .25; %probabilidade de erro
ber = []; %pr� alocando vetor com resultados ber
for n = 2:2:16 %la�o para simula�oes aumentando gradualmente o n�mero de bits repetidos
    lena_n = repmat(lena_b,[1 n+1]); %repete os bits
    tam_n = size(lena_n); %adquire novas dimens�es
    bsc_im = bsc(lena_n,pe); %simula canal bsc para um erro pe
    v_erro = sum(bsc_im,2); %soma cada bloco de bits repetidos
    resp = lena_n(:,1); %pr� alocando resposta
    for p = 1:tam_n(1) %la�o para corrigir os bits
        if v_erro(p) > (n+1)/2 %se a maioria dos bits de cada bloco for 1, resposta igual a 1
            resp(p,1) = 1;
        else %se a maioria dos bits de cada bloco for 0, resposta igual a 0
            resp(p,1) = 0;
        end
    end
    ber = [ber sum(abs(lena_b-resp),1)/tam_b(1)*100]; %calcula a ber
    figure %plotando imagem resultante
    im = uint8(bi2de(reshape(resp,[8 (tam_n(1))/8])')); %colocando no formato original
    im = reshape(im,tam); %colocando no formato original
    imshow(im) 
    xlabel(['n = ' num2str(n) ', ' '  BER = ' num2str(ber(end)) '$\%$' ' e $p_e=25\%$' ],'Interpreter','Latex','FontSize',14) %legenda
    saveas(gcf,['pe25' 'n' num2str(n) 'lena.pdf']) %salvando arquivo
end
figure %plotando ber
loglog(2:2:16,ber./100)
ylabel('BER','Interpreter','Latex','FontSize',14)
xlabel('$n$','Interpreter','Latex','FontSize',14)
grid on
saveas(gcf,'berxvsn.pdf')
