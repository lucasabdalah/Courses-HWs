lena = imread('lenaTest2.jpg'); %adquire imagem Lena como matriz
tam = size(lena); %obter tamanho da matriz da imagem
lena_v = double(reshape(lena,tam(1)*tam(2),1)); %reordena a matriz como um vetor
lena_b = de2bi(lena_v,8); %converte de decimal para bin�rio
tam_b = size(lena_b); %obtem tamanho da nova matriz com dados em bin�rio
pe = 0:.25:1; %vetor com probabilidades de erro de canal pe
bsc_im = zeros([tam_b length(pe)]); %pr� alocando array com imagens p�s passagem pelo canal
for p = 1:length(pe) %la�o para passagens do canal aumentando gradativamente o a probabilidade de eerro de transmiss�o
    bsc_im(:,:,p) = bsc(lena_b,pe(p)); %fun��o que simula canal bsc com para um erro pe
end
for p = 1:length(pe) %la�o para vizualir resultados
    im = uint8(reshape(bi2de(bsc_im(:,:,p)),tam)); %transformando imagens para seu formato otiginal
    figure %plotando resultados
    imshow(im) 
    xlabel(['$p_e = ' num2str(pe(p)*100)  '\%$' ],'Interpreter','Latex','FontSize',18) %legenda
    saveas(gcf,[num2str(pe(p)*100) 'errolena.pdf']) %salvando arquivo
end

